# REVENIR — Link da Bio Premium

Site estático pronto para GitHub Pages, sem bibliotecas externas. Layout visual fornecido em `assets/revenir-visual.png` com áreas de clique reais sobre os quatro botões.

## Links configurados
- Agende pelo WhatsApp: https://wa.me/5527988090155
- Nossos procedimentos: https://wa.me/c/5527988090155
- Nossos resultados: https://wa.me/c/5527988090155
- Nosso site: https://revenir.com.br/

**Importante:** Nossos procedimentos e Nossos resultados levam atualmente ao mesmo catálogo porque esses foram os links enviados. Altere o `href` de cada botão em `index.html` quando houver URLs diferentes.

## Publicar no GitHub Pages
1. Crie uma conta no https://github.com se necessário.
2. Crie um repositório público, por exemplo `revenir-links`.
3. Envie **o conteúdo da pasta** (o `index.html` e a pasta `assets/`) para a raiz do repositório.
4. Vá em Settings > Pages > Build and deployment; selecione Deploy from a branch, branch `main`, pasta `/ (root)`; salve.
5. Abra `https://SEUUSUARIO.github.io/revenir-links/` depois da publicação.

Não é necessário instalar nada nem compilar. Para testar localmente, abra `index.html` num navegador; imagem e links funcionam offline, exceto o destino dos links que precisa de internet.
